﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class tester : MonoBehaviour
{

    public float spacing = 0.1f;
    public float scaleOnY = 0.1f;
    public float Range = 1.0f;
    public int M = 10;
    public int N = 10;
    GameObject cube;
    GameObject[,] platform;
    float[,] nextPosition;
    float[,] currentPosition;
    public bool Simulate = true;
    Color[,] currentColor;
    Color[,] nextColor;
    Color red;
    Color green;
    Color blue;
    Color rgb;
    Color grey;
    float random;
    // Use this for initialization
    void Start()
    {
        platform = new GameObject[M, N];
        currentPosition = new float[M, N];
        nextColor = new Color[M, N];
        nextPosition = new float[M, N];

        for (int i = 0; i < M; i++)
        {
            for (int j = 0; j < N; j++)
            {
                GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
                cube.transform.position = new Vector3(i, 0, j);
                cube.transform.rotation = Quaternion.identity;
                cube.transform.localScale = new Vector3(1, scaleOnY, 1);
                cube.name = string.Format("Cube-{0}{1}", i, j);

                platform[i, j] = cube;//cube into the platform
                currentPosition[i, j] = platform[i, j].transform.position.y;
                nextPosition[i, j] = cube.transform.position.y;
                nextColor[i, j] = Color.grey;

            }
        }
    }

    // Update is called once per frame
    void Update()
    {

        if (Simulate)
        {
            if (platform != null)
            {
                for (int a = 0; a < M; a++)
                {
                    for (int b = 0; b < N; b++)
                    {






                        if (Mathf.Abs(platform[a, b].transform.position.y - nextPosition[a, b]) < 0.05f)//checks the distance between the current and next position
                        {
                            random = UnityEngine.Random.Range(-Range,Range);
                            nextPosition[a, b] = random;
                            currentPosition[a, b] = platform[a,b].transform.position.y;
                        }

                        // smooth transition the color ...
                        platform[a, b].transform.gameObject.GetComponent<Renderer>().material.color = Color.Lerp(platform[a, b].transform.gameObject.GetComponent<Renderer>().material.color, nextColor[a, b], Time.deltaTime);

                        // smooth transition the position
                        platform[a, b].transform.position = Vector3.Lerp(platform[a, b].transform.position, new Vector3(platform[a, b].transform.position.x, nextPosition[a, b], platform[a, b].transform.position.z), Time.deltaTime);
                    }
                }
            }
        }


        //KeyCodes
        //turns off simulation
        if (Input.GetKeyDown(KeyCode.T))
        {
            Simulate = !Simulate;
        }

        if (Input.GetKey(KeyCode.W))
        {
            Range += 1.0f;

        }
        if (Input.GetKey(KeyCode.S))
        {
            Range -= 1.0f;

            if (Range < 0f)
            {
                Range = 0f;
            }
        }

        for (int a = 0; a < M; a++)
        {
            for (int b = 0; b < N; b++)
            {
                if (Input.GetKey(KeyCode.R))
                {
                    red = new Color(Random.Range(0.0f, 1.0f), 0, 0);
                    nextColor[a, b] = red;
                }
                if (Input.GetKey(KeyCode.B))
                {
                    blue = new Color(0, 0, Random.Range(0.0f, 1.0f));
                    nextColor[a, b] = blue;
                }
                if (Input.GetKey(KeyCode.G))
                {
                    green = new Color(0, Random.Range(0.0f, 1.0f), 0);
                    nextColor[a, b] = green;
                }
                if (Input.GetKey(KeyCode.E))
                {
                    rgb = new Color(Random.Range(0.0f, 1.0f), Random.Range(0.0f, 1.0f), Random.Range(0.0f, 1.0f));
                    nextColor[a, b] = rgb;

                }
                if (Input.GetKey(KeyCode.H))
                {
                    float rand = Random.Range(0.0f, 1.0f);
                    grey = new Color(rand, rand, rand);
                    nextColor[a, b] = grey;
                }
                if(Input.GetKeyDown(KeyCode.Q)){
                    Application.Quit();
                }

            }

        }
    }
}