﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Text;
public class blockBuilder : MonoBehaviour {
    public Material blockmaterial;
    public Material baseMaterial;
    public Camera cameraMain;
    public GameObject transparentCube;
    private GameObject invisiCube;

    void Start()
    {

 invisiCube= (GameObject) Instantiate(transparentCube, transform.position, transform.rotation);


    }

    // Update is called once per frame
    void Update () {
        #region Screen to world
        RaycastHit hitinfo = new RaycastHit();
        bool hit = Physics.Raycast(cameraMain.ScreenPointToRay(Input.mousePosition), out hitinfo);

        if (hit)
        {
            if (hitinfo.transform.tag == "Base")
            {
                invisiCube.transform.position = new Vector3(hitinfo.point.x, hitinfo.point.y+ (0.5f),
                                                            hitinfo.point.z);
            }
            if(hitinfo.transform.tag == "MyCube") {
                invisiCube.transform.position = new Vector3(hitinfo.transform.position.x + (hitinfo.normal.x), (hitinfo.transform.position.y) + (hitinfo.normal.y),
                                                               (hitinfo.transform.position.z) + (hitinfo.normal.z));
            }

            if (Input.GetMouseButtonUp(0))
                {

                        var cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
                        cube.tag = "MyCube";
                        cube.GetComponent<Renderer>().material = blockmaterial;
                    cube.transform.position = invisiCube.transform.position;

                }

        }
        else
        {
            Debug.Log("No Hit");
        }
        #endregion
    }
}
